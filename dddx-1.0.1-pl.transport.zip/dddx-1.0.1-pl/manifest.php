<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b99cccd0520dd798ab3c4744e9c48161',
      'native_key' => 'dddx',
      'filename' => 'modNamespace/3a6e164a4d0a3edcaf80f739470a58b0.vehicle',
      'namespace' => 'dddx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'bb86c296b9c619758b6c4dff33a8dc82',
      'native_key' => 12,
      'filename' => 'modPlugin/114379990b3e729ca10b692384c372bb.vehicle',
      'namespace' => 'dddx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4b1941c795bdbbb4910b091a1617c6ad',
      'native_key' => 1,
      'filename' => 'modCategory/2a943487509998d57f78c3d822568230.vehicle',
      'namespace' => 'dddx',
    ),
  ),
);