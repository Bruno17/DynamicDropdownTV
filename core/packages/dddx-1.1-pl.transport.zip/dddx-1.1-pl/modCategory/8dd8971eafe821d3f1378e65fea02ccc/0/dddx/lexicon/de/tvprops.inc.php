<?php
/**
 * dddx
 *
 * @package dddx
 * @language de
 */


$_lang['dddx.dddxid'] = 'dddx ID';
$_lang['dddx.childs'] = 'dddx Kinder-Selects';
$_lang['dddx.parents'] = 'dddx Eltern-Selects';
$_lang['dddx.group'] = 'dddx Gruppe';
$_lang['dddx.parent'] = 'Übergeordnetes Dropdown';
$_lang['dddx.readonly'] = 'nur Lesen';
$_lang['dddx.firstText'] = 'erste Reihe Text';
$_lang['dddx.clearOnRefresh'] = 'bei Aktualisierung leeren'; 
$_lang['dddx.valueDelimiter'] = 'Trennzeichen';