<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e12b6fae8e9eb4ea57be6f42922bcea3',
      'native_key' => 'dddx',
      'filename' => 'modNamespace/46254a8d7457b8e5de54ba8dcda07d7f.vehicle',
      'namespace' => 'dddx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '1c217879ce186b90b668c7033b741edf',
      'native_key' => 12,
      'filename' => 'modPlugin/3bdb013a506cbe2c8ce521108d8d9113.vehicle',
      'namespace' => 'dddx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0c9970655e25095bde367e361e4fa1d1',
      'native_key' => 1,
      'filename' => 'modCategory/8dd8971eafe821d3f1378e65fea02ccc.vehicle',
      'namespace' => 'dddx',
    ),
  ),
);