<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '--------------------
dddx
--------------------
Version: 1.0.0
Author: Bruno Perner <b.perner@gmx.de>
--------------------

dynamic_dropdown-TV is a custom-tv-input-type for selecting related values
each dropdown can have on or more dynamic_dropdown-children, which are updated on selection 
 
Installation: by package-management

Example 1 (uses the default-processor):

Create 3 dynamic_dropdown-TVs:

name: dddx0
Parent Dropdown:
dddx Group: mygroup
where: {"parent":"0"}

name: dddx1
Parent Dropdown: dddx0
dddx Group: mygroup  
where: {"parent":"[[+dddx0]]"}

name: dddx2
Parent Dropdown: dddx1
dddx Group: mygroup
where: {"parent":"[[+dddx1]]"}  

 
Example 2 (with individual processors):
 
Create 3 dynamic_dropdown-TVs:

name: resource_level0
Parent Dropdown:
dddx Group: resource_levels 

name: resource_level1
Parent Dropdown: resource_level0
dddx Group: resource_levels     

name: resource_level2
Parent Dropdown: resource_level1
dddx Group: resource_levels  

Note: create all dropdown-TVs from up to down!

To work correctly, each dropdown needs to know all its parents and childs.
There is running a plugin (onTvFormSave), which collects all parents- and childs-dynamic_dropdowns of the same dddx-group and stores them in input-properties for each TV after saving the TV.  

This will add three dropdown-selects, where you can choose resources.
By selecting a resource of the first level. The next selectbox will open with childs of this resource.
By selecting one of the second level, the third one will open with its childs.


Build own sets:
choose your own group-name and create a new folder under 
/core/components/dddx/processors/mgr/your own group name

and create processor-files for each dropdown with names like:

getoptions.your-dynamic_dropdown-TV-name.php
all childs will send a requestParam with selected value of its parents and the name of its parents dynamic_dropdown-TV
see the files under /resource_levels for examples.

you can do live-searching in options
with 
Enable Type-Ahead: true
and
Force Selection to List: true


',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6c0dfd952e644836e5a7c017cb469c88',
      'native_key' => 'dddx',
      'filename' => 'modNamespace/a45e648259328561b464a52385bbb684.vehicle',
      'namespace' => 'dddx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '93140bdd6070777143ce0c91a26dcfd6',
      'native_key' => 13,
      'filename' => 'modPlugin/c68e4dfb35fdc3294d1f84bb2cc975f0.vehicle',
      'namespace' => 'dddx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8722eb443b68e6c8307045b9ba1e2b77',
      'native_key' => 1,
      'filename' => 'modCategory/20bd75b22e7c50a62093f260cd686e76.vehicle',
      'namespace' => 'dddx',
    ),
  ),
);