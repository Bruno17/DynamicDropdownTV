<?php
/**
 * dddx
 *
 * @package dddx
 * @language en
 */


$_lang['dddx.dddxid'] = 'dddx ID';
$_lang['dddx.childs'] = 'dddx Child-Selects';
$_lang['dddx.parents'] = 'dddx Parent-Selects';
$_lang['dddx.group'] = 'dddx Group';
$_lang['dddx.parent'] = 'Parent Dropdown';
$_lang['dddx.readonly'] = 'readonly';
$_lang['dddx.firstText'] = 'first row text';

