<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a4482e0f2ddbf0bdab70a40829727f6d',
      'native_key' => 'dddx',
      'filename' => 'modNamespace/b63a91229e5e2e4042b371732f7b4d5b.vehicle',
      'namespace' => 'dddx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'f1fa03a48f08ae9678618f0ace37b251',
      'native_key' => 12,
      'filename' => 'modPlugin/3c4730d16c7cc330aeaed7f5a26bab72.vehicle',
      'namespace' => 'dddx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1e11ec8c60878384688bc21559aa85a1',
      'native_key' => 1,
      'filename' => 'modCategory/6676b6b680048bc99ace61e3d0e84911.vehicle',
      'namespace' => 'dddx',
    ),
  ),
);