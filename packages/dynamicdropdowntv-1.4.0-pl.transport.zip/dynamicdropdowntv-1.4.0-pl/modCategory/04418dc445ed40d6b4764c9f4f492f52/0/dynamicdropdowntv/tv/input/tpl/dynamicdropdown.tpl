<input type="hidden" id="original{$ddId}" name="original{$tv->id}" value="{$tv->get('value')|escape}" />

<div id="div_{$ddId}">

</div>


<script type="text/javascript">
// <![CDATA[
{literal}

MODx.combo.{/literal}{$ddId}{literal} = function(config) {
    config = config || {};
    Ext.applyIf(config,{{/literal}
        name: '{$ddId}'
        ,id: 'select_{$ddId}'
        ,width: 400
        ,hiddenName: 'tv{$tv->id}'
        ,renderTo: 'div_{$ddId}'
        ,children: Ext.decode('{$children}')
        ,parents: Ext.decode('{$parents}')          
        {if $params.title},title: '{$params.title|escape:'javascript'}'{/if}
        {if $params.listWidth},listWidth: {$params.listWidth}{/if}
        ,maxHeight: {if $params.maxHeight}{$params.maxHeight}{else}300{/if}
        {if $params.typeAhead}
            ,editable: true
            ,typeAhead: true
            ,typeAheadDelay: {if $params.typeAheadDelay && $params.typeAheadDelay != ''}{$params.typeAheadDelay}{else}250{/if}
        {else}
            ,editable: false
            ,typeAhead: false
        {/if}
        {if $params.listEmptyText}
            ,listEmptyText: '{$params.listEmptyText|escape:'javascript'}'
        {/if}
        ,forceSelection: {if $params.forceSelection && $params.forceSelection != 'false'}true{else}false{/if}
        ,initiated: false
        ,allowBlank: {if $params.allowBlank == 1 || $params.allowBlank == 'true'}true{else}false{/if}
		,resizable: false
        ,pageSize: 0		
        ,url: {$connector_path}
        ,fields: ['id','name']
        ,displayField: 'name'
        ,valueField: 'id'
        {literal}
        ,baseParams: {
		    action: '{/literal}{$action}{literal}'
            ,resource_id: '{/literal}{$resource.id}{literal}' 
            ,object_id: '{/literal}{$object_id}{literal}'
            ,tvname: '{/literal}{{$tv->name}}{literal}' 	 	            
        }
		,listeners: {
		    'select': {fn:this.selectOption,scope:this}
            ,'render': {fn:this.initSelect,scope:this}
		}
    });
    MODx.combo.{/literal}{$ddId}{literal}.superclass.constructor.call(this,config);
};
Ext.extend(MODx.combo.{/literal}{$ddId}{literal},MODx.combo.ComboBox,{
	selectOption: function() {
        this.refreshChildren(true);
        MODx.fireResourceFormChange();	         
        
	}
    ,reload: function() {
        this.store.load({
            callback: function() {
                this.setValue('');
                this.refreshChildren(true);
            },scope:this
       });
	}
    ,refreshChildren: function(reload) {
        var ddSelect = null;
        for(var i = 0; i <  this.children.length; i++) {
 		    var child = this.children[i];
            ddSelect = Ext.getCmp('select_'+child);
            if(typeof(ddSelect) != "undefined"){
                ddSelect.baseParams.{/literal}{$ddId}{literal} = this.getValue();
                ddSelect.store.baseParams.{/literal}{$ddId}{literal} = this.getValue();
                if (reload){
                    ddSelect.reload();
                }
            }
        }
	}    
    ,initSelect: function() {
        var parent_field = null;
        for(var i = 0; i <  this.parents.length; i++) {
 		    var parent = this.parents[i];
            parent_field = Ext.get('original'+parent);
            if (parent_field){
                this.baseParams[parent] = parent_field.dom.value;
            }
        }
        this.store.on('exception', function() {
            console.warn('DynamicDropdownTV: Failed to load options');
        });
        this.store.load({
            callback: function() {
                this.setValue(Ext.get('{/literal}original{$ddId}{literal}').dom.value);
            },scope:this
       });
	}

});
Ext.reg('modx-combo-{/literal}{$ddId}{literal}',MODx.combo.{/literal}{$ddId}{literal});
Ext.onReady(function() {
    var fld = MODx.load({
        xtype: 'modx-combo-{/literal}{$ddId}{literal}'

    });
    
    Ext.getCmp('modx-panel-resource').getForm().add(fld);
    {/literal}
});
// ]]>
</script>