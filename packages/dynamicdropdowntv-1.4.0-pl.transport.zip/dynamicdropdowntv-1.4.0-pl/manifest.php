<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => 'DynamicDropdownTV — Custom dual-compat build by João Nogueira from original release 1.3.0 by Bruno Perner
==========================================================================================================

This is a maintenance fork of the original DynamicDropdownTV extra by
Bruno Perner. It refreshes the codebase for modern PHP and MODX:

- PHP 8.x compatibility — every undefined-array-key access path was
  guarded, the inverted count() parenthesis bug in OnTVFormSave was
  fixed, and the $scriptProperty[$key] mutation bug in the default
  getoptions processor was rewritten to write to $scriptProperties
  instead.

- MODX 3 compatibility — replaced the removed $modx->toJson() /
  $modx->fromJson() calls with json_encode() / json_decode() and
  swapped the deprecated Ext.util.JSON.decode for Ext.decode in the
  ExtJS templates.

- Defense in depth — the asset connector now requires an authenticated
  manager session before dispatching the request, matching the policy
  used by the bundled cttupdater extra.

Original copyright (c) 2012-2013 Bruno Perner, GPL-2.0+.
Custom dual-compat patches (c) 2026 João Nogueira.

Installation
------------
Install from Manager > Extras > Installer > Add New Package > Upload
Package. Pick the dynamicdropdowntv-x.y.z-pl.transport.zip file.
The extra registers a plugin (DynamicDropdownTV) bound to the TV
input/inputoption render-list events and to OnTVFormSave.

Compatibility
-------------
- MODX Revolution 2.6+ (manager UI assumes ExtJS-based MODX manager).
- MODX 3.x.
- PHP >= 7.4 (tested on PHP 8.5).

Dependencies
------------
- MIGX (any current version) must be installed.


Original DynamicDropdownTV Documentation by Bruno Perner
========================================================

DynamicDropdownTV
================================================================================

Dynamic dropdown custom template variable for MODX Revolution.

Features
--------------------------------------------------------------------------------
With this MODX Revolution custom template variable related dropdown template
variables could be used. Each dynamic dropdown template variable could have one
or more child dynamic dropdown template variables which are updated on selection
of the parent dynamic dropdown template variable. 

Installation
--------------------------------------------------------------------------------
MODX Package Management

Examples
--------------------------------------------------------------------------------

Example 1: Default processor usage (XPDO Package)
················································································

Create three Dynamic Dropdown template variables:

First

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name                   | dynamic0
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Parent Dropdown        |
Input Options       | Dynamic Dropdown Group | dynamicGroup
Input Options       | Where                  | {"parent":"0"}

Second

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name                   | dynamic1
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Parent Dropdown        | dynamic0
Input Options       | Dynamic Dropdown Group | dynamicGroup
Input Options       | Where                  | {"parent":"[[+dynamic0:default=`999999999999999`]]"}

Third

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name                   | dynamic2
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Parent Dropdown        | dynamic1
Input Options       | Dynamic Dropdown Group | dynamicGroup
Input Options       | Where                  | {"parent":"[[+dynamic1:default=`999999999999999`]]"}

The names dynamicX and dynamicGroup are just examples and could be changed.

This example will add three dropdown select TVs, where you can choose MODX
resources. After selecting a resource in the first TV dynamic0, the dropdown
select of the second TV dynamic1 will show the childs of this resource. After
selecting a resource in the second TV dynamic1, the dropdown select of the third
TV dynamic2 will show the childs of this resource. If you select again a
resource in the first TV dynamic0 all children of this Dynamic Dropdown TV
(dynamic1 and  dynamic2) will be resetted.

Example 2: Default processor usage (Input Option Values)
················································································

Create two Dynamic Dropdown template variables:

First

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name                   | dynamic0
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Dynamic Dropdown Group | dynamicGroup
Input Options       | Input Option Values    | TEST1==1||TEST2==2

Second

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name | dynamic1
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Dynamic Dropdown Group | dynamicGroup
Input Options       | Input Option Values    | 1::TEST1a==1a||TEST1a==1a##2::TEST2b==2b||TEST2b==2b

The names dynamicX and dynamicGroup are just examples and could be changed.

This example will add two dropdown select TVs, where you can different values. After selecting a value in the first TV dynamic0, the dropdown select of the second TV dynamic1 will show related values. If you select again a value in the first TV dynamic0 all children of this Dynamic Dropdown TV (dynamic1) will be reseted.

The format for the input option values is:
Parentvalue::Key==Value||…||Key==Value##Parentvalue::Key==Value||…||Key==Value

Creating a new line after the ## is allowed.

Example 3: Individual processor usage
················································································

Create three Dynamic Dropdown template variables:

First

Tab                 | Option                 | Value
------------------- | ---------------------- | ---------------
General Information | Name                   | resource_level0
Input Options       | Parent Dropdown        |
Input Options       | Dynamic Dropdown Group | resource_levels

Second

Tab                 | Option                 | Value
------------------- | ---------------------- | ---------------
General Information | Name                   | resource_level1
Input Options       | Parent Dropdown        | resource_level0
Input Options       | Dynamic Dropdown Group | resource_levels

Third

Tab                 | Option                 | Value
------------------- | ---------------------- | ---------------
General Information | Name                   | resource_level2
Input Options       | Parent Dropdown        | resource_level1
Input Options       | Dynamic Dropdown Group | resource_levels

This example will also add three dropdown select TVs, where you can choose MODX
resources. After selecting a resource in the first TV resource_level0, the
dropdown select of the second TV resource_level1 will show the childs of this
resource. After selecting a resource in the second TV resource_level1, the
dropdown select of the third TV resource_level2 will show the childs of this
resource. If you select again a resource in the first TV resource_level0 all
children of this Dynamic Dropdown TV (resource_level1 and resource_level2) will
be resetted.

The above example uses the example processors in
/core/components/dynamicdropdowntv/processors/mgr/resource_levels.

Create the individual processors
················································································

If you want to create your own processors, choose a group name and create a new
folder in /core/components/dynamicdropdowntv/processors/mgr/your-own-group-name.
Then create processor files for each dynamic dropdown template variable with
names like getoptions.your-dynamic-dropdown-tv-name.php.

All child Dynamic Dropdown TVs will send the name and the selected value of the
parent Dynamic Dropdown TV as request parameter pair to the processor.

If no folder with the group name exists in
/core/components/dynamicdropdowntv/processors/mgr
the default processors are used (as in example 1).

Example 3: Gallery album processor usage:
················································································

Create two Dynamic Dropdown template variables

First

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name                   | albums0
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Parent Dropdown        |
Input Options       | Dynamic Dropdown Group | gallery_albums

Second

Tab                 | Option                 | Value
------------------- | ---------------------- | ----------------
General Information | Name                   | albums1
Input Options       | Input Type             | Dynamic Dropdown
Input Options       | Parent Dropdown        | albums0
Input Options       | Dynamic Dropdown Group | gallery_albums

This example will also add two dropdown select TVs, where you can choose MODX
gallery albums. After selecting a gallery album in the first TV albums0, the
dropdown select of the second TV albums1 will show the child albums of this
album. If you select again a album in the first TV albums0 the child of this
Dynamic Dropdown TV (albums1) will be resetted.

Notes
--------------------------------------------------------------------------------

1. Create all Dynamic Dropdown from up to down!
2. To work correctly, each Dynamic Dropdown TV needs to know all its parents and
   childs. There is a plugin in onTvFormSave, which collects all parents and
   children Dynamic Dropdown TVs of the same Dynamic Dropdown group and stores
   them in input-properties for each TV after saving the TV.
3. You can live search in dropdown select options if you set Enable Type-Ahead
   to Yes and set Force Selection to List to Yes.
',
    'changelog' => 'DynamicDropdownTV — Changelog
=============================

1.4.0 — Forked by João Nogueira from the original release from Bruno Perner
-------------------------------------------------------------------------
- MODX 3 from-scratch processor refactor. Convert the include-style
  getoptions.default.php and getelements.default.php to class-based
  processors (*.class.php) extending modProcessor. MODX 3 only loads
  class-style processors via its action lookup, so the legacy include
  files produced "Requested processor not found" on every dropdown
  options fetch when editing a record. Legacy .php files are kept in
  place so existing direct references continue to work on MODX 2.
- Processor-level permission gate: explicit checkPermissions() requiring
  an authenticated manager session, in addition to the existing
  defense-in-depth check in connector.php.
- Input render: per-TV override processor lookup now prefers .class.php
  and falls back to legacy .php, so existing custom override processors
  shipped with the package keep working on MODX 2 and can be upgraded to
  class style for MODX 3.
- MigX-on-MODX-3 dropdown fix: When the DDTV input renderer was invoked
  from inside MigX form-builder pipeline on MODX 3, $modx->controller
  was null. The DDTV input render classes now route placeholders and
  template fetching through $modx->smarty when the controller is
  unavailable.
- Critical plugin-cache fix: The build script was shipping the plugin
  source with its opening <?php tag still in place causing a fatal parse
  error in the cached plugin include. The build now strips the leading
  <?php before persisting the plugincode column.
- PHP 8.x compatibility: every undefined-array-key access path was
  guarded, the inverted count() parenthesis bug in OnTVFormSave was
  fixed, and the $scriptProperty[$key] mutation bug in the default
  getoptions processor was rewritten.
- MODX 3 compatibility: replaced the removed $modx->toJson() /
  $modx->fromJson() calls with json_encode() / json_decode() and
  swapped the deprecated Ext.util.JSON.decode for Ext.decode in the
  ExtJS templates.
- Security: the asset connector now requires an authenticated manager
  session before dispatching the request. XSS fixes (object_id cast,
  TPL escaping), template injection sanitization, path traversal
  prevention on group parameter.
- UX/JS: fixed global variable leaks in for loops, fixed store.baseParams
  sync in multi-select cascading, added AJAX error handling.
- Verified end-to-end on MODX 2.8.8 and MODX 3.2.1 (PHP 8.5).

1.3.0
-----
- Original release line by Bruno Perner.
',
    'setup-options' => 'dynamicdropdowntv-1.4.0-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4.0',
      'migx' => '>=2.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6617ceb86b61726a4e75024e4fb046da',
      'native_key' => 'dynamicdropdowntv',
      'filename' => 'modNamespace/3152f2f619e0d21681564358bec2ed83.vehicle',
      'namespace' => 'dynamicdropdowntv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '30fbff2c9982c1bedc236a3b52383ec8',
      'native_key' => 1,
      'filename' => 'modCategory/04418dc445ed40d6b4764c9f4f492f52.vehicle',
      'namespace' => 'dynamicdropdowntv',
    ),
  ),
);